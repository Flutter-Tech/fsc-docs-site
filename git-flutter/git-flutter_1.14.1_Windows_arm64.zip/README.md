# Flutter Shared Codebase (fsc) CLI

<a href=https://developers.flutter.com/catalogue/fsc-cli-tool target=_blank><img src="https://github.com/Flutter-Global/fsc-docs-site-internal/blob/gh-pages/assets/svg/fsc-cli-tool.svg" title="Learn more about fsc-cli-tool in the Service Catalogue"></a>

[![Flutter Catalogue](https://img.shields.io/badge/flutter-%20docs-blue)](https://developers.flutter.com/catalogue/fsc-cli-tool/)

A cli tool to support administration and governance of the Flutter inner source [development model and conventions](https://innersource.flutter.com/).

```
$ fsc help
A command line assistant for Flutter shared code

Usage:
  fsc [command]

Available Commands:
  apply       Parse and  optionally apply a set of changes
  audit       Check the audit log for actionable events
  csv         Export a data csv
  doctor      Check the repo and suggest improvements
  governor    Action codebases.json changes
  help        Help about any command
  inspect     Inspect all the repos in the org
  lint        Lint codebases.json file
  md          Generates and exports markdown content to stdout or a file/dir.
  security    Display a security assessment
  update      Update local snapshot of GitHub data
  upgrade     Upgrades codebases.json file to the latest version
  version     Displays the version string
```

This repository is part of the [inner source automation](https://github.com/Flutter-Global/cap-inner-source-automation) capability within the [inner source product](https://github.com/Flutter-Global/product-inner-source).

For more information:

- [read our documentation site](https://developers.flutter.com/)
- [join the #inner-source slack channel](https://slack.com/app_redirect?channel=C0115SW13V5)
- email the inner source team `InnerSourceTeam@flutter.com` or contact Rob Tuley (team lead) directly.

## Install 

Currently required to be built from source. If you have go installed, `make` will build a statically linked executable `fsc` in the repo root directory:

```
make
./fsc version
```

Alternatively if you don't have go installed, you can build a docker-packaged executable:

```
docker build -t fsc .
docker run -it --rm --name fsc-running fsc version
```

## Provide a GitHub Token

The cli requires access to GitHub via an auth token for many admin functions. This can be provided by the `FG_APP_TOKEN` environment variable. The token requires the permission scopes:

* `repo` to access repository meta-data
* `admin:org` to get members, pending invitations seem to require write perms
* `read:user` to access member meta-data

The `fsc update` command retrieves data from GitHub APIs and populates a local cache that is then used by the other commands.

## Using Codespaces

We welcome contributions! This repository is configured for GitHub Codespaces and the `FG_APP_TOKEN` can be [configured as a codespace secret](https://github.com/settings/codespaces) for the repository. [Further information in the contributing guide](./CONTRIBUTING.md). 
